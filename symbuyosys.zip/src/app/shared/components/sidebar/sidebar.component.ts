import { Component } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.scss'
})
export class SidebarComponent {

  user ={
    name: 'John Doe',
    company: 'Company',
  }

  menuItems = [
    { name: 'Dashboard', icon: '', route: '/dashboard' },
    { name: 'Home', icon: '', route: '/home' },
    { name: 'Menu Item 1', icon: '', route: '/menu1' },
    { name: 'Menu Item 2', icon: '', route: '/menu2' },
    { name: 'Menu Item 3', icon: '', route: '/menu3' },
    { name: 'Menu Item 4', icon: '', route: '/menu4' },
  ];
}
